export const metadata = { title: 'Forbidden' }
export default function ForbiddenPage() {
  return (
    <div>
      <h1>Access denied</h1>
      <p>You don’t have permission to view this page.</p>
    </div>
  )
}
