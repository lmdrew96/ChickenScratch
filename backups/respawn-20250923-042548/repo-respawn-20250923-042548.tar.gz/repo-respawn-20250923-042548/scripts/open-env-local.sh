cd "$(dirname "$0")/.."
open -a TextEdit .env.local
